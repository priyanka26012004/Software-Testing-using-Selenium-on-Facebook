from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# Initialize Chrome WebDriver (you may choose a different browser)
driver = webdriver.Chrome()

try:
    #test case:1
    driver.get("https://facebook.com/")
    print("Navigated to facebook page")

    #test case:2
    driver.maximize_window()
    print("maximized")

    #test case:3
    try:
        email_input = driver.find_element(By.ID, "email")
        password_input = driver.find_element(By.ID, "pass")
        login_button = driver.find_element(By.NAME, "login")
        email_input.send_keys("nandinibs65@gmail.com")
        password_input.send_keys("9741501051")
        time.sleep(4)
        login_button.click()
        print("Invalid email")
    except Exception as e:
        print("Test case 3 failed: {str(e)}")

    #test case:4
    try:
        email_input = driver.find_element(By.ID, "email")
        password_input = driver.find_element(By.ID, "pass")
        login_button = driver.find_element(By.NAME, "login")
        email_input.send_keys("nandinibs78@gmail.com")
        password_input.send_keys("9741501051")
        login_button.click()
        print("Login credential")
    except Exception as e:
        print("Login Credential are correct: {str(e)}")

    #test case:5
    try:
        WebDriverWait(driver, 10).until(
            EC.url_contains("facebook.com"))
        print("Logged in successfully!")
        time.sleep(5)
    except Exception as e:
        print("Login Failed: {str(e)}")

    # test case:6
    try:
        profile_link = "https://www.facebook.com/me/"
        driver.get(profile_link)
        WebDriverWait(driver, 10).until(EC.url_contains("https://www.facebook.com/profile.php?id=100068172883256"))
        print("Profile Page")
    except Exception as e:
        print("Can't navigate to profile page: {str(e)}")

    # test case:7
    try:
        driver.get('https://www.facebook.com')
        time.sleep(5)
        stories_button = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div[2]/div/div/div[2]/div/div/div/a/div/div/div[2]/div/div[1]')
        stories_button.click()
        time.sleep(5)
        print("Story Viewed")
    except Exception as e:
        print("Story can't play: {str(e)}")

    #test case:8
    try:
        time.sleep(5)
        driver.get("https://www.facebook.com/")
        time.sleep(5)
        WebDriverWait(driver, 10).until(
            EC.url_contains("facebook.com")
        )
        search_box = driver.find_element(By.XPATH, "/html/body/div[1]/div/div[1]/div/div[2]/div[3]/div/div/div/div/div/label")
        friend_name = "Yogendra Gowda"
        search_box.send_keys(friend_name)
        search_box.send_keys(Keys.ENTER)
        time.sleep(5)  # Example: Wait for 5 seconds
        print("search succesfull")
    except Exception as e:
        print("Search unsuccesfull: {str(e)}")

    #test case:9
    try:
        driver.get("https://www.facebook.com/")
        time.sleep(2)
        driver.get("https://www.facebook.com/profile.php?id=100054760446222")
        add_friend_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div/div[1]/div[2]/div/div/div[1]/div[4]/div/div/div[1]/div/div/div, 'Add Friend')]"))
        )
        time.sleep(3)
        add_friend_button.click()
        time.sleep(3)
        print("Friend request sent successfully.")
    except Exception as e:
        cancel_request_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div/div[1]/div[2]/div/div/div[1]/div[4]/div/div/div[1]/div/div/div"))
        )
        time.sleep(3)
        cancel_request_button.click()
        time.sleep(3)
        print("Friend request canceled successfully.")

    # test case:10
    try:
        driver.get("https://www.facebook.com/")
        driver.get("https://www.facebook.com/friends/requests/")
        WebDriverWait(driver, 10).until(EC.url_contains("facebook.com/friends/requests"))
        time.sleep(3)
        accept_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
             (By.XPATH,
            "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div[1]/div/div[2]/div[1]/div[2]/div/div[4]/div[2]/div/a/div[1]/div[2]/div/div[2]/div/div/div[1]/div[1]/div"))
        )
        accept_button.click()
        print("Friend request accepted")
    except Exception as e:
        print("Can't accept friend request: {str(e)}")

    #test case:11
    try:
        driver.get("https://www.facebook.com/")
        time.sleep(2)
        driver.get("https://www.facebook.com/friends/requests/")
        WebDriverWait(driver, 10).until(EC.url_contains("facebook.com/friends/requests"))
        delete_buttons = driver.find_elements(By.XPATH,
                                         "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div[1]/div/div[2]/div[1]/div[2]/div/div[4]/div[3]/div/a/div[1]/div[2]/div/div[2]/div/div/div[2]")
        if not delete_buttons:
           print("No friend requests found.")
        else:
            delete_buttons[0].click()
            print("First friend request deleted successfully!")
        time.sleep(3)
    except Exception as e:
        print("Test case 11 failed:{str(e)}")

    #test case:12
    try:
        driver.get("https://www.facebook.com/")
        time.sleep(2)
        first_post = driver.find_element(By.XPATH, "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div[2]/div/div/div/div[3]/div/div[4]/div/div[2]/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[13]/div/div")
        driver.execute_script("arguments[0].scrollIntoView(true);", first_post)
        like_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div/div[2]/div/div/div/div[3]/div/div[4]/div/div[2]/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[13]/div/div/div[4]/div/div/div[1]/div/div[2]/div/div[1]/div[1]/div[1]"))
        )
        like_button.click()
        print("Liked the first post.")
        time.sleep(3)
    except Exception as e:
        print("Test case 12 failed: {str(e)}")

    #test case:13
    try:
        videos_link = "https://www.facebook.com/watch/"
        driver.get(videos_link)
        WebDriverWait(driver, 10).until(EC.url_contains("https://www.facebook.com/watch"))
        time.sleep(5)
        first_video = driver.find_element(By.XPATH,
                      "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div[2]/div/div[2]/div/div/div/div/div/div[2]/div/div/div[1]/div/div/div/div/div/div[2]")
        first_video.click()
        time.sleep(10)
        print("video viewed")
    except Exception as e:
        print("Can't play video: {str(e)}")

    #test case:14
    try:
        driver.get("https://www.facebook.com/")
        marketplace_link = "https://www.facebook.com/marketplace/"
        driver.get(marketplace_link)
        WebDriverWait(driver, 10).until(EC.url_contains("marketplace"))
        first_post_xpath = "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div[2]/div/div/div/div/div/div/div[3]/div/div[1]/div/div/div/span/div/div/div/div[2]/div[1]/div/div/span/div/div/div/div/a/div/div[2]"  # Adjust this XPath based on the actual structure
        first_post = driver.find_element(By.XPATH,
                                     "/html/body/div[1]/div/div[1]/div/div[3]/div/div/div[1]/div[1]/div[2]/div/div/div/div/div/div/div[3]/div/div[1]/div/div/div/span/div/div/div/div[2]/div[1]/div/div/span/div/div/div/div/a/div/div[2]")
        first_post.click()
        time.sleep(4)
        print("navigated to market place")
    except Exception as e:
        print("Test case 14 failed:{str(e)}")

    #test case:15
    try:
        driver.get('https://www.facebook.com/settings?tab=privacy')
        time.sleep(5)
        print("Privacy settings updated successfully.")
    except Exception as e:
        print("Test case 15 failed: {str(e)}")

    # test case:16
    try:
        driver.get("https://www.facebook.com/")
        notifications_icon = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable(
                (By.XPATH, "/html/body/div[1]/div/div[1]/div/div[2]/div[5]/div[1]/div[3]/span/span/div"))
        )
        notifications_icon.click()
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH,
                                                                    "/html/body/div[1]/div/div[1]/div/div[2]/div[5]/div[2]/div/div/div[1]/div[1]/div/div/div/div/div/div/div[1]/div[3]/div[2]/div/div/div[2]/div[1]/div/a/div[1]")))
        print("Opened notifications page")
        time.sleep(5)
    except Exception as e:
        print("Can't open notification: {str(e)}")

    # test case:17
    try:
        messenger_icon = driver.find_element(By.XPATH, "/html/body/div[1]/div/div[1]/div/div[2]/div[5]/div[1]/div[2]/span")
        messenger_icon.click()
        time.sleep(5)
        print("opened message page")
    except Exception as e:
        print("can't open message page: {str(e)}")

    #test case:18
    try:
        profile_link = driver.find_element(By.XPATH, "/html/body/div[1]/div/div[1]/div/div[2]/div[5]/div[1]/span")
        profile_link.click()
        time.sleep(5)
        profile_name = driver.find_element(By.XPATH, "/html/body/div[1]/div/div[1]/div/div[2]/div[5]/div[2]/div/div/div[1]/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div/div[1]/div[1]/div/div/a/div[1]/div[2]/span")
        print(f"Profile Name: {profile_name.text}")
    except Exception as e:
        print("Cannot display profile name: {str(e)}")

    #test case:19
    try:
        logout_button = driver.find_element(By.XPATH,"/html/body/div[1]/div/div[1]/div/div[2]/div[5]/div[2]/div/div/div[1]/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div/div[1]/div[2]/div/div[5]/div/div[1]")
        logout_button.click()
        print("Logout Successfull")
    except Exception as e:
        print("Can not logout: {str(e)}")

except Exception as e:
    print(f"Exception occurred: {str(e)}")

finally:
    # Close the browser
    driver.quit()